<template>
  <div :class="{ 'todo-item': true, completed: todo.completed }">
    <span>{{ todo.text }}</span> <!-- текст задания -->
    <button @click="$emit('remove')">Удалить</button> <!-- кнопка для удаления задачи -->
    <button @click="$emit('toggle')"> <!-- кнопка для переключения статуса задачи -->
      {{ todo.completed ? 'Не выполнено' : 'Выполнено' }} <!-- заменя текста -->
    </button>
  </div>
</template>

<script>
export default {
  name: 'TodoItem', 
  props: {
    todo: { // параметр "todo"
      type: Object, 
      required: true 
    }
  }
}
</script>

<style scoped>
.todo-item { 
  display: flex; 
  justify-content: space-between; 
  align-items: center; 
}
.completed { 
  text-decoration: line-through; 
  color: grey; 
}
</style>