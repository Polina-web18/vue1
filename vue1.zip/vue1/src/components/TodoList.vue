<template>
    <div>
        <h1>Список дел</h1>
        
        <input v-model="newTodo" @keyup.enter="addTodo" placeholder="Добавить новую задачу" />
        <button @click="addTodo">Добавить</button>
        
        <div v-for="todo in todos" :key="todo.id">
            <todo-item
                :todo="todo"
                @remove="removeTodo(todo.id)"  
                @toggle="toggleTodoStatus(todo.id)"  
            ></todo-item>
        </div>
    </div>
</template>

<script>
import TodoItem from './TodoItem.vue'; // импорт компонента для отдельной задачи

export default {
    name: 'TodoList',
    components: {
        TodoItem
    },
    data() {
        return {
            newTodo: '', 
            todos: [] // список задач
        };
    },
    methods: {
        addTodo() {
            // проверка на пустую задачу
            if (this.newTodo.trim() === '') return;

            // создание новой задачи
            const newTask = {
                id: Date.now(), // id задачи
                text: this.newTodo,
                completed: false 
            };
            this.todos.push(newTask); 
            this.newTodo = '';
        },
        removeTodo(id) {
            this.todos = this.todos.filter(todo => todo.id !== id);
        },
        toggleTodoStatus(id) {
            const todo = this.todos.find(todo => todo.id === id);
            if (todo) {
                todo.completed = !todo.completed; // переключение статуса
            }
        }
    }
}
</script>

<style scoped>
h1 {
    margin-bottom: 10px;
}
</style>